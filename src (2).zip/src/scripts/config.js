export const ACCESS_TOKEN_KEY = "token";

export const BASE_URL = "https://story-api.dicoding.dev/v1";

export const MAP_SERVICE_API_KEY = "AkTUUAkPw4fN7OQtqJE2";

export const VECTOR_STYLE_URL =
  "https://api.maptiler.com/maps/01971757-ca5d-7afa-9e61-0295a5e3d878/style.json?key=s62TUO5FD6q5IjoosYVw";

export const VAPID_PUBLIC_KEY =
  "BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk";
